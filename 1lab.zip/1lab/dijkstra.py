import texttable


MAX_COST = 1000

# Вариант 11
matrix = [
    [0, 5, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 2, 0, 0],
    [0, 0, 0, 0, 0, 2, 1, 0],
    [0, 5, 4, 0, 0, 1, 3, 0],
    [0, 0, 0, 0, 0, 2, 3, 5],
    [0, 0, 0, 0, 0, 0, 1, 3],
    [0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0]
]

# цена перехода из начальной точки в точку с индексом i
costs = [0] + [MAX_COST] * (len(matrix) - 1)

ways = [0] * len(matrix)


def is_not_discovered(point: int):
    return costs[point] == MAX_COST


def dijkstra(current_point: int, current_way: list):
    global costs
    global ways

    for next_point in range(len(matrix[current_point])):
        if matrix[current_point][next_point] == 0:  # no way
            continue

        if is_not_discovered(next_point) or \
                costs[next_point] > costs[current_point] + matrix[current_point][next_point]:
            costs[next_point] = costs[current_point] + matrix[current_point][next_point]
            way_to_next_point = current_way + [next_point]
            ways[next_point] = way_to_next_point
            dijkstra(next_point, way_to_next_point)


def print_result_table():
    global costs
    global ways

    tab = texttable.Texttable()
    tab.header(['To Point', 'Cost', 'Way'])
    for row in zip([x for x in range(len(matrix[0]))], costs, ways):
        tab.add_row(row)
    print(tab.draw())


if __name__ == '__main__':
    start_point = 0
    start_way = [0]
    dijkstra(start_point, start_way)
    print("*** RESULT ***")
    print_result_table()
